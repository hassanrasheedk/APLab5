object SieveofEratosthenes {

  def main(args: Array[String]): Unit ={
    print("Enter a number: ")
    val num = readInt()
    print(primesAre(num))
  }

  def SieveofEratosthenes(A: List[Int], B: List[Int]): List[Int] =
    A match {
      case Nil => B.reverse
      case p::xs => SieveofEratosthenes(xs.filter(x => x % p > 0), p :: B)
    }

  def primesAre(max: Int) = SieveofEratosthenes(List.range(2, max + 1), Nil)
}